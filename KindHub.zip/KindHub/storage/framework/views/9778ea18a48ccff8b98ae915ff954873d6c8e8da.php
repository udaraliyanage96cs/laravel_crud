<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
  
    <!------ Include the above in your HEAD tag ---------->
    
    <script src="http://ajax.googleapis.com/ajax/libs/jquery/1.9.1/jquery.min.js"></script>
    <script src="http://getbootstrap.com/dist/js/bootstrap.min.js"></script>
    <title>KindHub School</title>

    <link href="https://fonts.googleapis.com/css?family=Raleway:100,600" rel="stylesheet" type="text/css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" ></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="font-awesome/css/font-awesome.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Oswald:wght@500&family=Roboto&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="/css/welcome.css">
</head>
<body>
    <div class="addcsv">
        <div class="container">
            <form method='post' action='/uploadExcel' enctype='multipart/form-data' >
                <?php echo e(csrf_field()); ?>

                <input type='file' name='file' class="btn btn-warning">
                <input type='submit' name='submit' value='Import' class="btn btn-success">
            </form>
        </div>
    </div>

    <div class="container addmanual">
        <form method='post' action='/addStudent'>
            <?php echo e(csrf_field()); ?>

            <div class="row">
                <div class="teacher spc">
                    <select class=" custom-select form-control " name="teacher" required>
                        <option selected disabled value="" >Select Teacher</option>
                        <?php $__currentLoopData = $data['tech']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $thr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($thr->id); ?>"><?php echo e($thr->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="classroom spc">
                    <select class=" custom-select form-control  " name="classroom" required>
                        <option selected disabled value="" >Select Class</option>
                        <?php $__currentLoopData = $data['cls']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cls): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($cls->id); ?>"><?php echo e($cls->name); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="fname spc">
                <input type="text"  name="fname" class="form-control " placeholder="First Name"> 
                </div>
                <div class="lname spc">
                    <input type="text"  name="lname" class="form-control " placeholder="Last Name"> 
                </div>
                <div class="classroom spc">
                    <select class=" custom-select form-control  " name="gender" required>
                        <option selected disabled value="" >Select Gender</option>
                        <option value="M">Male</option>
                        <option value="F">Female</option>
                    </select>
                </div>
                <div class="year spc">
                    <input type="number"  name="year" class="form-control" placeholder="Joined Year"> 
                </div>
                
                <div class="button spc sub ml-auto">
                    <input type="submit"  name="submit" class="btn btn-success" value="+ Add"> 
                </div>
            </div>
        </form>
    </div>
    <div class="container dattable">
        <div class="row">
            <div class="col-md-12">
            <h4>All Students Records</h4>
            <div class="table-responsive">
                    <table id="mytable" class="table table-bordred table-striped">
                        <thead>
                            <th><input type="checkbox" id="checkall" /></th>
                            <th>Id</th>
                            <th>First Name</th>
                            <th>Last Name</th>
                            <th>Gender</th>
                            <th>Joined Year</th>
                            <th>Class Name</th>
                            <th>Teacher Name</th>
                            <th>Edit</th>
                            <th>Delete</th>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data['std']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $da): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <form method='post' action='/update/<?php echo e($da->id); ?>'>
                                    <?php echo e(csrf_field()); ?>

                                    <td><input type="checkbox" class="checkthis" /></td>
                                    <td><?php echo e($da->id); ?></td>
                                    <td><input type="text"  name="fname" class="form-control " value="<?php echo e($da->f_name); ?>"></td>
                                    <td><input type="text"  name="lname" class="form-control " value="<?php echo e($da->l_name); ?>"></td>
                                    <td><?php echo e($da->gender); ?></td>
                                    <td><?php echo e($da->joined_year); ?></td>
                                    <td><?php echo e($da->class_name); ?></td>
                                    <td><?php echo e($da->teacher_name); ?></td>
                                    <td><input type="submit" class="btn btn-primary btn-xs" name='submit' value="Eddit"></td>
                                    <td><a class="btn btn-danger btn-xs" href="/deleteUser/<?php echo e($da->id); ?>">Delete</a></td>
                                </form>
                            </tr>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
            
                    </table>
    
                   
                    
                </div>
                
            </div>
        </div>
    </div>
    
    
   
    <div class="modal fade" id="loginmodal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Modal title</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="/login/<?php echo e($da->id); ?>" method="POST">
                    <?php echo e(csrf_field()); ?>

                    <div class="form-group">
                        <input type="email" name="email" placeholder="udara@example.abc" class="form-control txt">
                        <input type="password" name="password" placeholder="Password Here" class="form-control txt">
                        <div class="row ml-auto">
                            <input type="submit" value="Login" name="Submit" class="btn btn-primary lgnbtn">
                            <input type="reset" value="Clear" name="clear" class="btn btn-warning">
                        </div>
                    </div>
                </form>
            </div>
            </div>
        </div>
    </div>

<script>
    $(document).ready(function(){
        $("#mytable #checkall").click(function () {
            if ($("#mytable #checkall").is(':checked')) {
                $("#mytable input[type=checkbox]").each(function () {
                    $(this).prop("checked", true);
                });

            } else {
                $("#mytable input[type=checkbox]").each(function () {
                    $(this).prop("checked", false);
                });
            }
        });
        
        $("[data-toggle=tooltip]").tooltip();
    });

</script>
</body>
</html>