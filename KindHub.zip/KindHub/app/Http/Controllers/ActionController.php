<?php

namespace App\Http\Controllers;
use App\teacher;
use App\classroom;
use App\student;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ActionController extends Controller
{
    public function index(){
        $getStd = DB::select('SELECT students.id,students.f_name,students.l_name,students.gender,students.joined_year,teachers.name as teacher_name,classrooms.name as class_name FROM students,teachers,classrooms WHERE students.teacher_id= teachers.id AND students.classroom_id = classrooms.id');
        $getTeacher = DB::select('select * from teachers');
        $getClsass = DB::select('select * from classrooms');

        if($getStd != null){
            $data = [
                "std" => $getStd,
                "tech" => $getTeacher,
                "cls" => $getClsass
            ];
        }else{
            $data = [
                "std" => null,
                "tech" => $getTeacher,
                "cls" => $getClsass
            ];
        }
        
        
        return view('/welcome')->with('data',$data);
    }
    public function DeletUser(Request $request){
        $stdid = $request->id;
        DB::delete('delete from students where id = '.$stdid);
        return $this->index();
    }
    public function UpdateStudent(Request $request){
        $stdid = $request->id2;
        $fname = $request->fname;
        $lname = $request->lname;
        DB::update("update students set f_name = '$fname' , l_name= '$lname' where id = ".$stdid);
        return $this->index();
    }
    public function insetData(Request $request){
        $std = new student;
        $std->f_name = $request->fname;
        $std->l_name = $request->lname;
        $std->gender = $request->gender;
        $std->joined_year = $request->year;
        $std->classroom_id = $request->classroom;
        $std->teacher_id = $request->teacher;
        $std->save();
        return $this->index();
        
    }
    public function saveData(Request $request){

        if ($request->input('submit') != null ){
            $file = $request->file('file');
            // File Details 
            $filename = $file->getClientOriginalName();
            $extension = $file->getClientOriginalExtension();
            $tempPath = $file->getRealPath();
            $fileSize = $file->getSize();
            $mimeType = $file->getMimeType();
      
            // Valid File Extensions
            $valid_extension = array("csv");
            // 2MB in Bytes
            $maxFileSize = 2097152; 
            // Check file extension
            if(in_array(strtolower($extension),$valid_extension)){
              // Check file size
              if($fileSize <= $maxFileSize){
                // File upload location
                $location = 'uploads';
                // Upload file
                $file->move($location,$filename);
                // Import CSV to Database
                $filepath = public_path($location."/".$filename);
                // Reading file
                $file = fopen($filepath,"r");
                $importData_arr = array();
                $i = 0;
                while (($filedata = fgetcsv($file, 1000, ",")) !== FALSE) {
                   $num = count($filedata );
                   if($i == 0){
                      $i++;
                      continue; 
                   }
                   for ($c=0; $c < $num; $c++) {
                      $importData_arr[$i][] = $filedata [$c];
                   }
                   $i++;
                }
                fclose($file);

                $validate1 = 0;// to known class added finish
                $validate2 = 0;// to known class added finish
                $teacher = array();//for get uniq names of teacher
                $classroom = array();//for get uniq names of teacher
                $student = array();//for get uniq names of student
                foreach($importData_arr as $importData){
                    $teacher[] = $importData[1];
                    $classroom[] = $importData[0];

                    $student[] = [
                        "clsname"=>$importData[0],
                        "thrname"=>$importData[1],
                        "f_name"=>$importData[2],
                        "l_name"=>$importData[3],
                        "gender"=>$importData[4],
                        "joined_year"=>$importData[5]
                    ];
                }
                
                $newteacher[] = array_unique($teacher);// make Teachers array unique 
                $newclassroom[] = array_unique($classroom);// make Classroom array unique

                $clsroom = array_values($newclassroom[0]);// re arrange array to 0

                for($i=0;$i<=count($newteacher);$i++){ //Add Data to Database Table -> teachers
                    //echo $newar[0][$i];
                     $teach = new teacher;
                     $teach->name = $newteacher[0][$i];
                     $teach->save();
                     $validate1 = 1;
                }
                $clsroom_array_length = count($clsroom);
                for($j=0;$j<$clsroom_array_length;$j++){ //Add Data to Database Table -> teachers
                   // echo $clsroom[$j];
                    $cls = new classroom;
                    $cls->name = $clsroom[$j];
                    $cls->save();
                    $validate2 = 1;
                }
                $student_array_length = count($student);
                for($k=0;$k<$student_array_length;$k++){ //Add Data to Database Table -> teachers
                   // echo $clsroom[$j];
                    $std = new student;
                    $std->f_name = $student[$k]["f_name"];
                    $std->l_name = $student[$k]["l_name"];
                    $std->gender = $student[$k]["gender"];
                    $std->joined_year = $student[$k]["joined_year"];
                     
                    $clsname = $student[$k]["clsname"];
                    $thrname = $student[$k]["thrname"];

                    if($validate1 ==1 &&  $validate2 == 1){
                        $clsidarr = DB::select("select * from classrooms where name = '$clsname'");
                        $clsid = $clsidarr[0]->id;
                        $thridarr = DB::select("select * from teachers where name = '$thrname'");
                        $teacherid = $thridarr[0]->id;
                        
                        $std->classroom_id = $clsid;
                        $std->teacher_id = $teacherid;
                        $std->save();
                    }else{
                        echo "Not Finished";
                    }
                    
                }
               // dd($clsid);
              }else{
               // Session::flash('message','File too large. File must be less than 2MB.');
              }
      
            }else{
               //Session::flash('message','Invalid File Extension.');
            }
      
          }
          // Redirect to index
          return redirect()->action('PagesController@index');
        }
    
}
